print('JS-ContextFlow [INFO]');
context.setVariable('logging.contex.flow', context.flow);
context.setVariable('logging.error.state', context.getVariable('error.state'));